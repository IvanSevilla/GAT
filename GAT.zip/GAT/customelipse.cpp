#include "customelipse.h"

CustomElipse::CustomElipse(QObject *parent) :
    QGraphicsEllipseItem(),QObject(parent)
    {}

CustomLine::CustomLine(QObject *parent) :
     QGraphicsLineItem(),QObject(parent)
    {}
